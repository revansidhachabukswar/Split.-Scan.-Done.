export interface TokenResponse {
  access_token: string;
  token_type: string;
  merchant_id: string | null;
  role: string;
}

export interface AnalyzeResponse {
  amount: number;
  payment_type: string;
  matched_rule_name: string | null;
  threshold: number;
  estimated_mdr: number;
  disclaimer: string;
}

export interface SplitResponse {
  amount: number;
  mode: string;
  parts: number[];
}

export interface TransactionPart {
  id: string;
  part_index: number;
  amount: number;
  upi_uri: string;
  qr_base64: string;
  status: string;
}

export interface TransactionOut {
  id: string;
  invoice_number: string;
  total_amount: number;
  number_of_parts: number;
  split_mode: string;
  payment_type: string | null;
  estimated_mdr_total: number;
  status: string;
  customer_name: string | null;
  created_at: string;
  parts: TransactionPart[];
}

export interface TransactionSummary {
  id: string;
  invoice_number: string;
  total_amount: number;
  number_of_parts: number;
  status: string;
  customer_name: string | null;
  created_at: string;
}

export interface DashboardResponse {
  business_name: string;
  today_sales: number;
  today_transactions: number;
  pending_payments: number;
  total_qr_plans: number;
  total_installments: number;
  average_payment: number;
  pending_amount: number;
  daily_sales: { date: string; sales: number }[];
}

export interface PaymentRule {
  id: string;
  rule_name: string;
  payment_type: string;
  merchant_category: string | null;
  threshold_amount: number;
  mdr_percentage: number;
  fixed_mdr: number | null;
  maximum_mdr: number | null;
  effective_date: string;
  expiry_date: string | null;
  status: string;
  source_reference: string | null;
}

export interface Employee {
  id: string;
  full_name: string;
  mobile_number: string | null;
  is_active: boolean;
}
