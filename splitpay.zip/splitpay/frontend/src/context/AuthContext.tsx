import React, { createContext, useContext, useState, useCallback } from "react";
import { api } from "../api/client";
import type { TokenResponse } from "../types";

interface AuthState {
  token: string | null;
  role: string | null;
  merchantId: string | null;
  businessName: string | null;
  isAuthenticated: boolean;
  login: (mobile_number: string, password: string) => Promise<void>;
  register: (payload: {
    business_name: string;
    merchant_upi_id: string;
    mobile_number: string;
    business_category?: string;
    owner_name: string;
    password: string;
  }) => Promise<void>;
  logout: () => void;
  setBusinessName: (name: string) => void;
}

const AuthContext = createContext<AuthState | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(localStorage.getItem("splitpay_token"));
  const [role, setRole] = useState<string | null>(localStorage.getItem("splitpay_role"));
  const [merchantId, setMerchantId] = useState<string | null>(localStorage.getItem("splitpay_merchant_id"));
  const [businessName, setBusinessNameState] = useState<string | null>(localStorage.getItem("splitpay_business_name"));

  const persist = (resp: TokenResponse) => {
    localStorage.setItem("splitpay_token", resp.access_token);
    localStorage.setItem("splitpay_role", resp.role);
    if (resp.merchant_id) localStorage.setItem("splitpay_merchant_id", resp.merchant_id);
    setToken(resp.access_token);
    setRole(resp.role);
    setMerchantId(resp.merchant_id);
  };

  const login = useCallback(async (mobile_number: string, password: string) => {
    const { data } = await api.post<TokenResponse>("/api/auth/login", { mobile_number, password });
    persist(data);
  }, []);

  const register = useCallback(async (payload: any) => {
    const { data } = await api.post<TokenResponse>("/api/auth/register", payload);
    persist(data);
    setBusinessNameState(payload.business_name);
    localStorage.setItem("splitpay_business_name", payload.business_name);
  }, []);

  const logout = useCallback(() => {
    localStorage.clear();
    setToken(null);
    setRole(null);
    setMerchantId(null);
    setBusinessNameState(null);
  }, []);

  const setBusinessName = useCallback((name: string) => {
    setBusinessNameState(name);
    localStorage.setItem("splitpay_business_name", name);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        token,
        role,
        merchantId,
        businessName,
        isAuthenticated: !!token,
        login,
        register,
        logout,
        setBusinessName,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
