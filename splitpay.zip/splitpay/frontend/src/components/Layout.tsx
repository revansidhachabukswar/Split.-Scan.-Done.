import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const navItems = [
  { to: "/", label: "Home", icon: "🏠" },
  { to: "/history", label: "History", icon: "🧾" },
  { to: "/rules", label: "Rules", icon: "📋" },
  { to: "/assistant", label: "Assistant", icon: "💬" },
  { to: "/more", label: "More", icon: "⋯" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const { businessName, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col bg-[#f4f7f5]">
      <header className="sticky top-0 z-20 bg-white border-b border-gray-100 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand-600 text-white flex items-center justify-center font-bold text-sm">
            SP
          </div>
          <div>
            <div className="font-semibold text-sm leading-tight">SplitPay</div>
            {businessName && <div className="text-[11px] text-gray-500 leading-tight">{businessName}</div>}
          </div>
        </div>
        <button
          onClick={() => {
            logout();
            navigate("/login");
          }}
          className="text-xs text-gray-400 hover:text-gray-600"
        >
          Log out
        </button>
      </header>

      <main className="flex-1 max-w-md mx-auto w-full px-4 pt-4 pb-24">{children}</main>

      <nav className="fixed bottom-0 left-0 right-0 z-20 bg-white border-t border-gray-100 max-w-md mx-auto w-full">
        <div className="grid grid-cols-5">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex flex-col items-center justify-center py-2 text-[11px] gap-0.5 ${
                  isActive ? "text-brand-600 font-semibold" : "text-gray-400"
                }`
              }
            >
              <span className="text-lg leading-none">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
