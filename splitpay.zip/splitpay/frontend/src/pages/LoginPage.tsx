import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(mobile, password);
      navigate("/");
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Invalid mobile number or password.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center bg-[#f4f7f5] px-6 py-10">
      <div className="max-w-sm mx-auto w-full">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-brand-600 text-white flex items-center justify-center font-bold text-xl mx-auto mb-3">
            SP
          </div>
          <h1 className="text-2xl font-bold text-ink-900">SplitPay</h1>
          <p className="text-sm text-gray-500 mt-1">Split. Scan. Done.</p>
        </div>

        <form onSubmit={submit} className="bg-white rounded-2xl shadow-sm p-5 space-y-4">
          <h2 className="font-semibold text-lg">Log in</h2>
          <label className="block">
            <span className="text-xs font-medium text-gray-600 mb-1 block">Mobile Number</span>
            <input required value={mobile} onChange={(e) => setMobile(e.target.value)} className="input" placeholder="10-digit mobile number" />
          </label>
          <label className="block">
            <span className="text-xs font-medium text-gray-600 mb-1 block">Password</span>
            <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="input" placeholder="Password" />
          </label>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button disabled={loading} className="btn-primary w-full">
            {loading ? "Logging in…" : "Log In"}
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-5">
          New merchant?{" "}
          <Link to="/register" className="text-brand-600 font-medium">
            Create an account
          </Link>
        </p>
      </div>
    </div>
  );
}
