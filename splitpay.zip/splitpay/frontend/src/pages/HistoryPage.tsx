import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";
import type { TransactionSummary } from "../types";
import Layout from "../components/Layout";

const FILTERS = [
  { key: "today", label: "Today" },
  { key: "week", label: "This Week" },
  { key: "month", label: "This Month" },
  { key: "", label: "All" },
];

export default function HistoryPage() {
  const [period, setPeriod] = useState("today");
  const [search, setSearch] = useState("");
  const [items, setItems] = useState<TransactionSummary[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (period) params.period = period;
      if (search) params.search = search;
      const res = await api.get<TransactionSummary[]>("/api/transactions", { params });
      setItems(res.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period]);

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    load();
  };

  const statusColor = (status: string) =>
    status === "SUCCESS"
      ? "bg-brand-100 text-brand-700"
      : status === "PENDING"
      ? "bg-amber-100 text-amber-700"
      : "bg-red-100 text-red-700";

  return (
    <Layout>
      <h1 className="text-lg font-bold mb-4">Transaction History</h1>

      <form onSubmit={onSearchSubmit} className="mb-3">
        <input
          className="input"
          placeholder="Search invoice, customer, amount…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </form>

      <div className="flex gap-2 mb-4 overflow-x-auto no-scrollbar">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setPeriod(f.key)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border ${
              period === f.key ? "bg-brand-600 text-white border-brand-600" : "bg-white text-gray-600 border-gray-200"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading && <p className="text-sm text-gray-400">Loading…</p>}
      {!loading && items.length === 0 && <p className="text-sm text-gray-400">No transactions found.</p>}

      <div className="space-y-2">
        {items.map((t) => (
          <Link
            key={t.id}
            to={t.status === "SUCCESS" ? `/receipt/${t.id}` : `/qr/${t.id}`}
            className="card !p-3 flex items-center justify-between block"
          >
            <div>
              <div className="text-sm font-semibold">{t.invoice_number}</div>
              <div className="text-xs text-gray-400">
                {t.customer_name || "Walk-in customer"} · {new Date(t.created_at).toLocaleDateString("en-IN")}
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold text-sm">₹{t.total_amount.toLocaleString("en-IN")}</div>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${statusColor(t.status)}`}>
                {t.status}
              </span>
            </div>
          </Link>
        ))}
      </div>
    </Layout>
  );
}
