import { useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";

interface ChatMsg {
  role: "user" | "assistant";
  text: string;
}

const SUGGESTIONS = [
  "How much did I collect today?",
  "Show my biggest transactions",
  "How much did I collect this week?",
  "Show pending payments",
];

export default function AssistantPage() {
  const [messages, setMessages] = useState<ChatMsg[]>([
    { role: "assistant", text: "Ask me about your sales — I only answer using your real transaction data." },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const ask = async (question: string) => {
    if (!question.trim()) return;
    setMessages((m) => [...m, { role: "user", text: question }]);
    setInput("");
    setLoading(true);
    try {
      const res = await api.post("/api/assistant/query", { question });
      setMessages((m) => [...m, { role: "assistant", text: res.data.answer }]);
    } catch {
      setMessages((m) => [...m, { role: "assistant", text: "Sorry, I couldn't process that just now." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <h1 className="text-lg font-bold mb-4">Business Assistant</h1>

      <div className="space-y-3 mb-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${
                m.role === "user" ? "bg-brand-600 text-white" : "bg-white border border-gray-100"
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}
        {loading && <p className="text-xs text-gray-400">Thinking…</p>}
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {SUGGESTIONS.map((s) => (
          <button key={s} onClick={() => ask(s)} className="text-xs px-3 py-1.5 rounded-full border border-gray-200 bg-white">
            {s}
          </button>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          ask(input);
        }}
        className="flex gap-2"
      >
        <input className="input flex-1" placeholder="Ask a question…" value={input} onChange={(e) => setInput(e.target.value)} />
        <button className="btn-primary px-4">Send</button>
      </form>
    </Layout>
  );
}
