import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { api } from "../api/client";
import type { AnalyzeResponse, SplitResponse } from "../types";
import Layout from "../components/Layout";

type SplitMode = "standard" | "equal" | "custom";

export default function AnalysisPage() {
  const location = useLocation() as { state?: { amount?: number } };
  const navigate = useNavigate();
  const amount = location.state?.amount;

  const [analysis, setAnalysis] = useState<AnalyzeResponse | null>(null);
  const [mode, setMode] = useState<SplitMode>("standard");
  const [maxInstallment, setMaxInstallment] = useState("2000");
  const [numParts, setNumParts] = useState("3");
  const [customParts, setCustomParts] = useState<string[]>([]);
  const [split, setSplit] = useState<SplitResponse | null>(null);
  const [customerName, setCustomerName] = useState("");
  const [customerMobile, setCustomerMobile] = useState("");
  const [orderNumber, setOrderNumber] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!amount) {
      navigate("/amount", { replace: true });
      return;
    }
    api.post<AnalyzeResponse>("/api/payment/analyze", { amount }).then((res) => setAnalysis(res.data));
  }, [amount]);

  const recomputeSplit = async (nextMode: SplitMode = mode) => {
    if (!amount) return;
    setError(null);
    try {
      const payload: any = { amount, mode: nextMode };
      if (nextMode === "standard") payload.max_installment = Number(maxInstallment) || 2000;
      if (nextMode === "equal") payload.num_parts = Number(numParts) || 2;
      if (nextMode === "custom") {
        const parts = customParts.map((p) => Number(p) || 0);
        payload.custom_parts = parts;
      }
      const res = await api.post<SplitResponse>("/api/payment/split", payload);
      setSplit(res.data);
      if (nextMode === "custom" && customParts.length === 0) {
        setCustomParts(res.data.parts.map((p) => String(p)));
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Could not compute split");
      setSplit(null);
    }
  };

  useEffect(() => {
    if (analysis) recomputeSplit(mode);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [analysis, mode, maxInstallment, numParts]);

  const switchToCustomFromCurrent = () => {
    if (split) setCustomParts(split.parts.map((p) => String(p)));
    setMode("custom");
  };

  const updateCustomPart = (idx: number, value: string) => {
    setCustomParts((prev) => prev.map((p, i) => (i === idx ? value : p)));
  };

  const addCustomPart = () => setCustomParts((prev) => [...prev, "0"]);
  const removeCustomPart = (idx: number) => setCustomParts((prev) => prev.filter((_, i) => i !== idx));

  const customSum = customParts.reduce((s, p) => s + (Number(p) || 0), 0);
  const customValid = amount ? Math.abs(customSum - amount) < 0.01 : false;

  useEffect(() => {
    if (mode === "custom" && customValid) {
      recomputeSplit("custom");
    } else if (mode === "custom") {
      setSplit({ amount: amount || 0, mode: "custom", parts: customParts.map((p) => Number(p) || 0) });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customParts]);

  const generateQr = async () => {
    if (!amount || !split) return;
    setLoading(true);
    setError(null);
    try {
      const payload: any = { amount, mode, customer_name: customerName || undefined, customer_mobile: customerMobile || undefined, order_number: orderNumber || undefined };
      if (mode === "standard") payload.max_installment = Number(maxInstallment) || 2000;
      if (mode === "equal") payload.num_parts = Number(numParts) || 2;
      if (mode === "custom") payload.custom_parts = customParts.map((p) => Number(p) || 0);

      const res = await api.post("/api/payment/generate-qr", payload);
      navigate(`/qr/${res.data.id}`, { state: { transaction: res.data } });
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Could not generate payment plan");
    } finally {
      setLoading(false);
    }
  };

  if (!amount) return null;

  return (
    <Layout>
      <h1 className="text-lg font-bold mb-4">Payment Analysis</h1>

      <div className="card mb-4">
        <Row label="Payment Amount" value={`₹${amount.toLocaleString("en-IN")}`} bold />
        {analysis && (
          <>
            <Row label="Payment Type" value={humanType(analysis.payment_type)} />
            <Row label="Configured Rule" value={analysis.matched_rule_name || "—"} />
            <Row label="Threshold" value={`₹${analysis.threshold.toLocaleString("en-IN")}`} />
            <Row label="Estimated MDR" value={`₹${analysis.estimated_mdr.toFixed(2)}`} accent />
          </>
        )}
        <p className="text-[11px] text-gray-500 mt-3 leading-relaxed">
          This is an estimate based on the currently configured rule. Actual charges depend on your
          merchant classification and payment provider/network rules.
        </p>
      </div>

      <div className="card mb-4">
        <div className="text-sm font-semibold mb-3">Split Engine</div>
        <div className="grid grid-cols-3 gap-2 mb-3">
          {(["standard", "equal", "custom"] as SplitMode[]).map((m) => (
            <button
              key={m}
              onClick={() => (m === "custom" ? switchToCustomFromCurrent() : setMode(m))}
              className={`rounded-xl py-2 text-xs font-semibold border ${
                mode === m ? "bg-brand-600 text-white border-brand-600" : "bg-white text-gray-600 border-gray-200"
              }`}
            >
              {m[0].toUpperCase() + m.slice(1)}
            </button>
          ))}
        </div>

        {mode === "standard" && (
          <label className="block mb-3">
            <span className="text-xs text-gray-500">Maximum installment (₹)</span>
            <input className="input mt-1" inputMode="numeric" value={maxInstallment} onChange={(e) => setMaxInstallment(e.target.value.replace(/[^0-9]/g, ""))} />
          </label>
        )}
        {mode === "equal" && (
          <label className="block mb-3">
            <span className="text-xs text-gray-500">Number of equal parts</span>
            <input className="input mt-1" inputMode="numeric" value={numParts} onChange={(e) => setNumParts(e.target.value.replace(/[^0-9]/g, ""))} />
          </label>
        )}
        {mode === "custom" && (
          <div className="mb-3 space-y-2">
            {customParts.map((p, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span className="text-xs text-gray-400 w-16">Payment {idx + 1}</span>
                <input
                  className="input flex-1 !py-1.5 text-sm text-right"
                  inputMode="decimal"
                  value={p}
                  onChange={(e) => updateCustomPart(idx, e.target.value.replace(/[^0-9.]/g, ""))}
                />
                {customParts.length > 1 && (
                  <button onClick={() => removeCustomPart(idx)} className="text-gray-400 text-sm">✕</button>
                )}
              </div>
            ))}
            <button onClick={addCustomPart} className="text-brand-600 text-xs font-medium">
              + Add installment
            </button>
            <div className={`text-xs font-semibold ${customValid ? "text-brand-700" : "text-red-600"}`}>
              Sum: ₹{customSum.toLocaleString("en-IN")} {customValid ? "✓ matches total" : `— must equal ₹${amount.toLocaleString("en-IN")}`}
            </div>
          </div>
        )}

        {split && (
          <div className="bg-brand-50 rounded-xl p-3 space-y-1">
            {split.parts.map((p, idx) => (
              <div key={idx} className="flex justify-between text-sm">
                <span className="text-gray-600">Payment {idx + 1}</span>
                <span className="font-semibold">₹{p.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card mb-4">
        <div className="text-sm font-semibold mb-3">Customer Details (optional)</div>
        <div className="space-y-2">
          <input className="input" placeholder="Customer name" value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
          <input className="input" placeholder="Customer mobile" value={customerMobile} onChange={(e) => setCustomerMobile(e.target.value)} />
          <input className="input" placeholder="Order number" value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} />
        </div>
      </div>

      {error && <p className="text-sm text-red-600 mb-3">{error}</p>}

      <button
        disabled={loading || (mode === "custom" && !customValid)}
        onClick={generateQr}
        className="btn-primary w-full"
      >
        {loading ? "Generating…" : "Generate Payment QR"}
      </button>
    </Layout>
  );
}

function humanType(t: string) {
  const map: Record<string, string> = {
    P2P: "Person to Person",
    P2M: "Merchant Payment",
    ESSENTIAL: "Essential Sector Payment",
    CAPITAL_MARKET: "Capital Market Payment",
  };
  return map[t] || t;
}

function Row({ label, value, bold, accent }: { label: string; value: string; bold?: boolean; accent?: boolean }) {
  return (
    <div className="flex justify-between items-center py-1">
      <span className="text-sm text-gray-500">{label}</span>
      <span className={`text-sm ${bold ? "font-bold text-lg" : "font-medium"} ${accent ? "text-brand-700" : ""}`}>{value}</span>
    </div>
  );
}
