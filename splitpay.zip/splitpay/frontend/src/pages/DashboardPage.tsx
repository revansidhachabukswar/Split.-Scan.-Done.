import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import type { DashboardResponse } from "../types";
import Layout from "../components/Layout";

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const { setBusinessName } = useAuth();
  const [data, setData] = useState<DashboardResponse | null>(null);
  const [amount, setAmount] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.get<DashboardResponse>("/api/dashboard").then((res) => {
      setData(res.data);
      setBusinessName(res.data.business_name);
    });
  }, []);

  const goToAmount = () => {
    setError(null);
    navigate("/amount", { state: { amount: amount ? Number(amount) : undefined } });
  };

  const generateWithAmount = () => {
    const n = Number(amount);
    if (!amount || isNaN(n) || n <= 0) {
      setError("Enter a valid amount first");
      return;
    }
    navigate("/analysis", { state: { amount: n } });
  };

  return (
    <Layout>
      <h1 className="text-xl font-bold mb-1">
        {greeting()}
        {data ? `, ${data.business_name}` : ""}
      </h1>
      <p className="text-sm text-gray-500 mb-4">Here's how today is going.</p>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <StatCard label="Today's Sales" value={data ? `₹${data.today_sales.toLocaleString("en-IN")}` : "—"} />
        <StatCard label="Today's Transactions" value={data ? String(data.today_transactions) : "—"} />
        <StatCard label="Pending Payments" value={data ? String(data.pending_payments) : "—"} accent />
        <StatCard label="Avg. Payment" value={data ? `₹${data.average_payment.toLocaleString("en-IN")}` : "—"} />
      </div>

      {data && data.daily_sales.some((d) => d.sales > 0) && (
        <div className="card mb-4">
          <div className="text-xs font-semibold text-gray-500 mb-2">Last 7 days</div>
          <ResponsiveContainer width="100%" height={100}>
            <LineChart data={data.daily_sales}>
              <XAxis dataKey="date" hide />
              <Tooltip formatter={(v) => [`₹${Number(v).toLocaleString("en-IN")}`, "Sales"]} labelFormatter={() => ""} />
              <Line type="monotone" dataKey="sales" stroke="#148c54" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="card">
        <div className="text-sm font-semibold mb-3">Enter Customer Amount</div>
        <div className="flex items-center gap-2 mb-3">
          <span className="text-2xl font-bold text-gray-400">₹</span>
          <input
            inputMode="numeric"
            value={amount}
            onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
            placeholder="5000"
            className="text-3xl font-bold w-full outline-none bg-transparent"
            autoFocus
          />
        </div>
        {error && <p className="text-xs text-red-600 mb-2">{error}</p>}
        <button onClick={generateWithAmount} className="btn-primary w-full">
          Generate Payment QR
        </button>
        <button onClick={goToAmount} className="btn-secondary w-full mt-2">
          Open full amount entry / calculator
        </button>
      </div>
    </Layout>
  );
}

function StatCard({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className={`card !p-3 ${accent ? "border border-amber-200" : ""}`}>
      <div className="text-[11px] text-gray-500">{label}</div>
      <div className={`text-lg font-bold ${accent ? "text-amber-600" : "text-ink-900"}`}>{value}</div>
    </div>
  );
}
