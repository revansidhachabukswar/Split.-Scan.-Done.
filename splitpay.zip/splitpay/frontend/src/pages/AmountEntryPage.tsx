import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Layout from "../components/Layout";

const QUICK_AMOUNTS = [100, 500, 1000, 2000, 5000, 10000];

interface BillItem {
  id: number;
  label: string;
  amount: string;
}

export default function AmountEntryPage() {
  const location = useLocation() as { state?: { amount?: number } };
  const navigate = useNavigate();
  const [amount, setAmount] = useState<string>(location.state?.amount ? String(location.state.amount) : "");
  const [showCalc, setShowCalc] = useState(false);
  const [items, setItems] = useState<BillItem[]>([{ id: 1, label: "Item 1", amount: "" }]);

  const calcTotal = items.reduce((sum, i) => sum + (parseFloat(i.amount) || 0), 0);

  const addItem = () => setItems((prev) => [...prev, { id: prev.length + 1, label: `Item ${prev.length + 1}`, amount: "" }]);
  const updateItem = (id: number, field: "label" | "amount", value: string) =>
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, [field]: value } : i)));
  const removeItem = (id: number) => setItems((prev) => prev.filter((i) => i.id !== id));

  const applyCalcTotal = () => {
    setAmount(String(Math.round(calcTotal * 100) / 100));
    setShowCalc(false);
  };

  const canContinue = amount && Number(amount) > 0;

  const continueToAnalysis = () => {
    if (!canContinue) return;
    navigate("/analysis", { state: { amount: Number(amount) } });
  };

  return (
    <Layout>
      <h1 className="text-lg font-bold mb-4">Enter Amount</h1>

      <div className="card text-center mb-4">
        <div className="flex items-center justify-center gap-1">
          <span className="text-3xl font-bold text-gray-400">₹</span>
          <input
            inputMode="decimal"
            value={amount}
            onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
            placeholder="0"
            className="text-5xl font-extrabold text-center w-full outline-none bg-transparent"
            autoFocus
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-4">
        {QUICK_AMOUNTS.map((a) => (
          <button
            key={a}
            onClick={() => setAmount(String(a))}
            className="rounded-xl border border-gray-200 bg-white py-2 text-sm font-semibold text-gray-700 active:bg-gray-50"
          >
            ₹{a.toLocaleString("en-IN")}
          </button>
        ))}
      </div>

      <button onClick={() => setShowCalc((s) => !s)} className="btn-secondary w-full mb-4">
        {showCalc ? "Hide Calculator" : "🧮 Calculator (build a bill)"}
      </button>

      {showCalc && (
        <div className="card mb-4 space-y-2">
          {items.map((item) => (
            <div key={item.id} className="flex items-center gap-2">
              <input
                value={item.label}
                onChange={(e) => updateItem(item.id, "label", e.target.value)}
                className="input flex-1 !py-1.5 text-sm"
              />
              <input
                inputMode="decimal"
                value={item.amount}
                onChange={(e) => updateItem(item.id, "amount", e.target.value.replace(/[^0-9.]/g, ""))}
                placeholder="0"
                className="input w-24 !py-1.5 text-sm text-right"
              />
              {items.length > 1 && (
                <button onClick={() => removeItem(item.id)} className="text-gray-400 text-sm px-1">
                  ✕
                </button>
              )}
            </div>
          ))}
          <button onClick={addItem} className="text-brand-600 text-sm font-medium">
            + Add item
          </button>
          <div className="border-t border-dashed border-gray-200 pt-2 flex items-center justify-between font-semibold">
            <span>Total</span>
            <span>₹{calcTotal.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</span>
          </div>
          <button onClick={applyCalcTotal} className="btn-primary w-full mt-1">
            Use this total
          </button>
        </div>
      )}

      <button disabled={!canContinue} onClick={continueToAnalysis} className="btn-primary w-full">
        Generate Payment Plan
      </button>
    </Layout>
  );
}
