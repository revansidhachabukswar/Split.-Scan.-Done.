import { useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import type { TransactionOut } from "../types";
import Layout from "../components/Layout";

export default function QRPage() {
  const { transactionId } = useParams();
  const location = useLocation() as { state?: { transaction?: TransactionOut } };
  const navigate = useNavigate();
  const { businessName } = useAuth();

  const [txn, setTxn] = useState<TransactionOut | null>(location.state?.transaction || null);
  const [current, setCurrent] = useState(0);
  const [busy, setBusy] = useState(false);

  const fetchTxn = async () => {
    if (!transactionId) return;
    const res = await api.get<TransactionOut>(`/api/payment/${transactionId}`);
    setTxn(res.data);
  };

  useEffect(() => {
    if (!txn) fetchTxn();
  }, [transactionId]);

  if (!txn) {
    return (
      <Layout>
        <p className="text-sm text-gray-500">Loading payment plan…</p>
      </Layout>
    );
  }

  const allDone = txn.parts.every((p) => p.status === "MARKED_RECEIVED" || p.status === "SUCCESS");
  const part = txn.parts[current];

  const markReceived = async () => {
    setBusy(true);
    try {
      const res = await api.post<TransactionOut>(`/api/payment/${txn.id}/mark-received`, { part_id: part.id });
      setTxn(res.data);
    } finally {
      setBusy(false);
    }
  };

  if (allDone) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center text-center py-10">
          <div className="w-20 h-20 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center text-4xl mb-4">✓</div>
          <h1 className="text-xl font-bold mb-1">Payment Plan Complete</h1>
          <p className="text-sm text-gray-500 mb-6">Invoice {txn.invoice_number}</p>

          <div className="card w-full mb-6">
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-500">Total Amount</span>
              <span className="font-bold">₹{txn.total_amount.toLocaleString("en-IN")}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Installments</span>
              <span className="font-bold">{txn.number_of_parts}</span>
            </div>
          </div>

          <button onClick={() => navigate(`/receipt/${txn.id}`)} className="btn-primary w-full mb-2">
            View Receipt
          </button>
          <button onClick={() => navigate("/")} className="btn-secondary w-full">
            New Customer
          </button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="text-center mb-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">{businessName}</div>
        <div className="text-sm text-gray-400">Invoice {txn.invoice_number}</div>
      </div>

      <div className="text-center mb-4">
        <div className="text-sm font-semibold text-brand-700">
          PAYMENT {current + 1} OF {txn.parts.length}
        </div>
      </div>

      <div className="card flex flex-col items-center mb-4">
        <div className="text-4xl font-extrabold mb-4">₹{part.amount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</div>
        <img
          src={`data:image/png;base64,${part.qr_base64}`}
          alt={`QR code for payment ${current + 1}`}
          className="w-64 h-64 object-contain"
        />
        <p className="text-sm text-gray-500 mt-4">Ask customer to scan and pay</p>
        {part.status === "MARKED_RECEIVED" && (
          <p className="text-brand-600 font-semibold text-sm mt-2">✓ Marked as received</p>
        )}
      </div>

      <div className="flex items-center justify-center gap-2 mb-6">
        {txn.parts.map((p, i) => (
          <span
            key={p.id}
            className={`w-2.5 h-2.5 rounded-full ${
              p.status === "MARKED_RECEIVED" || p.status === "SUCCESS"
                ? "bg-brand-600"
                : i === current
                ? "bg-brand-300 ring-2 ring-brand-500"
                : "bg-gray-200"
            }`}
          />
        ))}
      </div>

      {part.status !== "MARKED_RECEIVED" && part.status !== "SUCCESS" && (
        <button disabled={busy} onClick={markReceived} className="btn-primary w-full mb-3">
          {busy ? "Saving…" : "Mark as Received"}
        </button>
      )}

      <div className="flex gap-3">
        <button
          disabled={current === 0}
          onClick={() => setCurrent((c) => Math.max(0, c - 1))}
          className="btn-secondary flex-1 disabled:opacity-40"
        >
          Previous
        </button>
        <button
          disabled={current === txn.parts.length - 1}
          onClick={() => setCurrent((c) => Math.min(txn.parts.length - 1, c + 1))}
          className="btn-secondary flex-1 disabled:opacity-40"
        >
          Next QR
        </button>
      </div>
    </Layout>
  );
}
