import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    business_name: "",
    merchant_upi_id: "",
    mobile_number: "",
    business_category: "",
    owner_name: "",
    password: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const update = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [field]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await register(form);
      navigate("/");
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Registration failed. Please check your details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center bg-[#f4f7f5] px-6 py-10">
      <div className="max-w-sm mx-auto w-full">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-brand-600 text-white flex items-center justify-center font-bold text-xl mx-auto mb-3">
            SP
          </div>
          <h1 className="text-2xl font-bold text-ink-900">SplitPay</h1>
          <p className="text-sm text-gray-500 mt-1">Split. Scan. Done.</p>
        </div>

        <form onSubmit={submit} className="bg-white rounded-2xl shadow-sm p-5 space-y-4">
          <h2 className="font-semibold text-lg">Create Merchant Account</h2>

          <Field label="Business Name" required>
            <input required value={form.business_name} onChange={update("business_name")} className="input" placeholder="ABC Store" />
          </Field>
          <Field label="Merchant UPI ID" required>
            <input required value={form.merchant_upi_id} onChange={update("merchant_upi_id")} className="input" placeholder="abcstore@upi" />
          </Field>
          <Field label="Owner Name" required>
            <input required value={form.owner_name} onChange={update("owner_name")} className="input" placeholder="Your name" />
          </Field>
          <Field label="Mobile Number" required>
            <input required value={form.mobile_number} onChange={update("mobile_number")} className="input" placeholder="10-digit mobile number" />
          </Field>
          <Field label="Business Category">
            <input value={form.business_category} onChange={update("business_category")} className="input" placeholder="e.g. General Retail" />
          </Field>
          <Field label="Password" required>
            <input required type="password" minLength={6} value={form.password} onChange={update("password")} className="input" placeholder="At least 6 characters" />
          </Field>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button disabled={loading} className="btn-primary w-full">
            {loading ? "Creating account…" : "Create Merchant Account"}
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-5">
          Already have an account?{" "}
          <Link to="/login" className="text-brand-600 font-medium">
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-gray-600 mb-1 block">
        {label} {required && <span className="text-red-500">*</span>}
      </span>
      {children}
    </label>
  );
}
