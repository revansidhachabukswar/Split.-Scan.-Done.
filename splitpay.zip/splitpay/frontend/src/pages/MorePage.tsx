import React, { useEffect, useState } from "react";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import type { Employee } from "../types";
import Layout from "../components/Layout";

export default function MorePage() {
  const { role } = useAuth();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ full_name: "", mobile_number: "", password: "" });
  const [error, setError] = useState<string | null>(null);

  const isOwner = role === "owner" || role === "admin";

  const load = () => {
    if (isOwner) api.get<Employee[]>("/api/employees").then((res) => setEmployees(res.data));
  };

  useEffect(load, [isOwner]);

  const addEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.post("/api/employees", form);
      setForm({ full_name: "", mobile_number: "", password: "" });
      setShowAdd(false);
      load();
    } catch (err: any) {
      setError(err?.response?.data?.detail || "Could not add employee");
    }
  };

  const deactivate = async (id: string) => {
    await api.patch(`/api/employees/${id}/deactivate`);
    load();
  };

  return (
    <Layout>
      <h1 className="text-lg font-bold mb-4">More</h1>

      {isOwner && (
        <div className="card mb-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-semibold">Employee Mode</span>
            <button onClick={() => setShowAdd((s) => !s)} className="text-brand-600 text-xs font-semibold">
              {showAdd ? "Cancel" : "+ Add Employee"}
            </button>
          </div>

          {showAdd && (
            <form onSubmit={addEmployee} className="space-y-2 mb-3">
              <input className="input" placeholder="Full name" required value={form.full_name} onChange={(e) => setForm((f) => ({ ...f, full_name: e.target.value }))} />
              <input className="input" placeholder="Mobile number" required value={form.mobile_number} onChange={(e) => setForm((f) => ({ ...f, mobile_number: e.target.value }))} />
              <input className="input" type="password" placeholder="Temporary password" required minLength={6} value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
              {error && <p className="text-xs text-red-600">{error}</p>}
              <button className="btn-primary w-full">Create Employee</button>
            </form>
          )}

          {employees.length === 0 && !showAdd && <p className="text-xs text-gray-400">No employees added yet.</p>}
          <div className="space-y-2">
            {employees.map((emp) => (
              <div key={emp.id} className="flex items-center justify-between border-t border-gray-50 pt-2 first:border-0 first:pt-0">
                <div>
                  <div className="text-sm font-medium">{emp.full_name}</div>
                  <div className="text-xs text-gray-400">{emp.mobile_number}</div>
                </div>
                {emp.is_active ? (
                  <button onClick={() => deactivate(emp.id)} className="text-xs text-red-500">
                    Deactivate
                  </button>
                ) : (
                  <span className="text-xs text-gray-400">Inactive</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="card mb-4 space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-500">Multi-branch support</span>
          <span className="text-gray-400 text-xs">Coming soon</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">App version</span>
          <span className="text-gray-400 text-xs">SplitPay 1.0.0</span>
        </div>
      </div>

      <p className="text-[11px] text-gray-400 leading-relaxed">
        SplitPay never stores UPI PINs, OTPs, bank passwords, or card credentials. Payments are always
        completed inside the customer's own UPI app.
      </p>
    </Layout>
  );
}
