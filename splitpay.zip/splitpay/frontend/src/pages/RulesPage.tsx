import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { PaymentRule } from "../types";
import Layout from "../components/Layout";

export default function RulesPage() {
  const [rules, setRules] = useState<PaymentRule[]>([]);

  useEffect(() => {
    api.get<PaymentRule[]>("/api/rules").then((res) => setRules(res.data));
  }, []);

  const feeLabel = (r: PaymentRule) => {
    if (r.fixed_mdr !== null && r.fixed_mdr !== undefined) {
      return r.fixed_mdr === 0 ? "Zero MDR" : `₹${r.fixed_mdr} flat MDR`;
    }
    if (r.mdr_percentage > 0) {
      return `${r.mdr_percentage}% MDR${r.maximum_mdr ? `, capped at ₹${r.maximum_mdr}` : ""}`;
    }
    return "Free";
  };

  return (
    <Layout>
      <h1 className="text-lg font-bold mb-1">Current UPI/MDR Rules</h1>
      <p className="text-xs text-gray-400 mb-4">
        Estimated MDR / applicable payment charge — figures are informational and depend on merchant
        classification, transaction type, and current payment-network rules.
      </p>

      <div className="space-y-3">
        {rules.map((r) => (
          <div key={r.id} className="card">
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-sm">{r.rule_name}</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-brand-100 text-brand-700">
                {r.payment_type}
              </span>
            </div>
            <div className="text-sm text-brand-700 font-semibold mb-1">{feeLabel(r)}</div>
            {r.threshold_amount > 0 && (
              <div className="text-xs text-gray-500">Applies above ₹{r.threshold_amount.toLocaleString("en-IN")}</div>
            )}
            <div className="text-xs text-gray-400 mt-1">
              Effective from {new Date(r.effective_date).toLocaleDateString("en-IN")}
            </div>
            {r.source_reference && (
              <details className="mt-2">
                <summary className="text-xs text-brand-600 cursor-pointer">View Source / Rule Reference</summary>
                <p className="text-[11px] text-gray-500 mt-1">{r.source_reference}</p>
              </details>
            )}
          </div>
        ))}
      </div>

      <p className="text-[11px] text-gray-400 mt-6 leading-relaxed">
        Splitting a payment does not guarantee that MDR or other charges will not apply. This page always
        reflects the rules currently configured for this deployment.
      </p>
    </Layout>
  );
}
