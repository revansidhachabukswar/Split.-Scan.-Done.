import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import type { TransactionOut } from "../types";
import Layout from "../components/Layout";

export default function ReceiptPage() {
  const { transactionId } = useParams();
  const { businessName } = useAuth();
  const [txn, setTxn] = useState<TransactionOut | null>(null);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    if (transactionId) {
      api.get<TransactionOut>(`/api/payment/${transactionId}`).then((res) => setTxn(res.data));
    }
  }, [transactionId]);

  const downloadPdf = async () => {
    if (!transactionId) return;
    setDownloading(true);
    try {
      const res = await api.get(`/api/payment/${transactionId}/receipt.pdf`, { responseType: "blob" });
      const url = window.URL.createObjectURL(new Blob([res.data], { type: "application/pdf" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = `receipt-${txn?.invoice_number || transactionId}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } finally {
      setDownloading(false);
    }
  };

  const share = async () => {
    const text = `${businessName} — Payment Receipt\nInvoice: ${txn?.invoice_number}\nTotal: ₹${txn?.total_amount.toLocaleString("en-IN")}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "SplitPay Receipt", text });
      } catch {
        /* user cancelled */
      }
    } else {
      await navigator.clipboard.writeText(text);
      alert("Receipt summary copied to clipboard");
    }
  };

  if (!txn) {
    return (
      <Layout>
        <p className="text-sm text-gray-500">Loading receipt…</p>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="card mb-4 print:shadow-none" id="receipt-block">
        <div className="text-center mb-4">
          <div className="font-bold text-lg uppercase">{businessName}</div>
          <div className="text-sm text-gray-500">Payment Receipt</div>
        </div>
        <div className="border-t border-dashed border-gray-200 my-3" />
        <Row label="Invoice" value={txn.invoice_number} />
        <Row label="Date" value={new Date(txn.created_at).toLocaleString("en-IN")} />
        {txn.customer_name && <Row label="Customer" value={txn.customer_name} />}
        <div className="border-t border-dashed border-gray-200 my-3" />
        {txn.parts.map((p) => (
          <div key={p.id} className="flex justify-between text-sm py-1">
            <span className="text-gray-600">Payment {p.part_index}</span>
            <span className="font-medium">
              ₹{p.amount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}{" "}
              {(p.status === "MARKED_RECEIVED" || p.status === "SUCCESS") && <span className="text-brand-600">✓</span>}
            </span>
          </div>
        ))}
        <div className="border-t border-dashed border-gray-200 my-3" />
        <div className="flex justify-between font-bold text-lg">
          <span>Total Paid</span>
          <span>₹{txn.total_amount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}</span>
        </div>
        {txn.estimated_mdr_total > 0 && (
          <p className="text-[11px] text-gray-400 mt-2">
            Estimated MDR/payment charge: ₹{txn.estimated_mdr_total.toFixed(2)} (informational only, does not guarantee final charges)
          </p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-2">
        <button onClick={() => window.print()} className="btn-secondary text-xs">
          Print
        </button>
        <button disabled={downloading} onClick={downloadPdf} className="btn-secondary text-xs">
          {downloading ? "…" : "Download PDF"}
        </button>
        <button onClick={share} className="btn-secondary text-xs">
          Share
        </button>
      </div>
    </Layout>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-sm py-0.5">
      <span className="text-gray-500">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
